import os, sys
try:
    __import__("SpY").apv()
except Exception as e:
    exit(str(e))
