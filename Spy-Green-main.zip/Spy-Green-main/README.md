# Spy-Green
Paid File clonar and file maker


# commands

pkg update 

pkg upgrade 

pkg install python 

pkg install python2

pkg install git

pip install requests 

pip install mechanize 

pip install temcolor

pip install bs4

pip install rich

rm -rf Spy-Green

git clone https://github.com/SPY-1x1/Spy-Green

cd Spy-Green

python spy.py 

# Paid tools 

This tools is paid..
You need parmation to use this tools...

# For Pro Programmer

Normal aproval system 

bypass kore nije k boro pro vabar kicu nai😪

be friendly be happy💖💖

# LOVE all Programmers
